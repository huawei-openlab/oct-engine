add the testing report
